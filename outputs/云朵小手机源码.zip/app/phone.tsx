'use client';
import {useState,useEffect,useRef,useCallback,useMemo} from 'react';
import {Cloud,Sparkles,RotateCw,ChevronLeft,Plus,Settings,Heart,Check,Wifi,Battery,Signal,MoreHorizontal,X,FolderHeart,CheckCheck,CloudCheck,CloudOff,LoaderCircle} from 'lucide-react';
import {APP_NAMES,stateSchema,type PhoneState,localDate} from '../lib/phone-model';
import {PhoneContext,Avatar,ButtonArt,DockArt,icons,type Commit} from './ui';
import Modules from './modules';
import Pet3D from './pet-3d';
import {buildPrompt,messageContent,parseUsage,type AIUsage} from '../lib/chat-prompt';
import {initializeLocal,writeLocal,readDeviceKey,saveDeviceKey,uploadLocal,getAsset,blobDataURL,LocalConflict,clearLegacyArchive} from '../lib/local-phone';
import {makeBackup,stageBackup,type PreparedBackup} from '../lib/local-backup';
import {getProvider,type ProviderId} from '../lib/providers';
import type {AIStats} from './ui';
export default function Phone({ownerId,appName='云朵小手机'}:{ownerId:string;appName?:string}){
 const [state,setState]=useState<PhoneState|null>(null),[app,setApp]=useState('home'),[detail,setDetail]=useState(''),[sync,setSync]=useState('loading'),[notice,setNotice]=useState(''),[legacyArchive,setLegacyArchive]=useState(false),[opening,setOpening]=useState('正在读取本机聊天和小日常…'),[keyEntry,setKeyEntry]=useState({provider:'',value:'',saved:false}),[busy,setBusy]=useState(false),[now,setNow]=useState<Date|null>(null);
 const [aiStats,setAIStats]=useState<AIStats>({last:null,requests:0,prompt:0,completion:0,firstTokenMs:null,durationMs:null,finishReason:''});
 const draftTimer=useRef<ReturnType<typeof setTimeout>|null>(null),pendingWrites=useRef(0),keyRevision=useRef(0),exporting=useRef(false);
 const data=useRef<PhoneState|null>(null),version=useRef(0),queue=useRef(Promise.resolve()),blocked=useRef(false),timer=useRef<ReturnType<typeof setTimeout>|null>(null);
 const apiKey=keyEntry.provider===state?.provider?keyEntry.value:'',savedAI=keyEntry.provider===state?.provider&&keyEntry.saved,serverAI=false,vision=state?.vision??false;
 const toast=useCallback((message:string)=>{setNotice(message);if(timer.current)clearTimeout(timer.current);timer.current=setTimeout(()=>setNotice(''),5000);},[]);
 const setApiKey=(value:string)=>{keyRevision.current++;setKeyEntry({provider:data.current?.provider||'',value,saved:false});};
 const reload=useCallback(async()=>{try{if(draftTimer.current){clearTimeout(draftTimer.current);draftTimer.current=null;}await queue.current;setSync('loading');const row=await initializeLocal(ownerId,setOpening);data.current=row.state;version.current=row.version;setLegacyArchive(!!row.legacyArchive);blocked.current=false;setState(row.state);setSync('saved');}catch(e){setSync('error');const message=e instanceof Error?e.message:'无法读取本机数据。';setOpening(message);toast(message);}},[ownerId,toast]);
 useEffect(()=>{void reload();setNow(new Date());const ticker=setInterval(()=>setNow(new Date()),30000);return()=>clearInterval(ticker);},[reload]);
 useEffect(()=>{if(!state)return;let active=true;const revision=keyRevision.current;void readDeviceKey(ownerId,state.provider).then(value=>{if(active&&revision===keyRevision.current)setKeyEntry({provider:state.provider,value,saved:!!value});}).catch(()=>toast('本机密钥未能读取，请在设置里重新填写。'));return()=>{active=false;};},[ownerId,state?.provider,toast]);
 const commit:Commit=useCallback((change)=>{
  if(!data.current)return Promise.reject(new Error('请等待数据加载。'));
  if(blocked.current){toast('保存尚未成功。请先重试保存或导出备份。');return Promise.reject(new Error('保存尚未成功。'));}
  const draft=structuredClone(data.current);try{change(draft);}catch(e){toast(e instanceof Error?e.message:'无法保存');return Promise.reject(e);}const validated=stateSchema.safeParse(draft);if(!validated.success){toast('这条内容超出了允许的长度或数量，请缩短后重试。');return Promise.reject(new Error('数据校验失败。'));}
  const next=validated.data;pendingWrites.current++;data.current=next;setState(next);setSync('saving');
  const operation=queue.current.then(async()=>{if(blocked.current)throw new Error('保存队列已暂停。');version.current=await writeLocal(ownerId,next,version.current);}).catch(e=>{if(!blocked.current){blocked.current=true;setSync(e instanceof LocalConflict?'conflict':'error');toast(e instanceof Error?e.message:'本机记录暂未保存。');}throw e;}).finally(()=>{pendingWrites.current--;if(!blocked.current)setSync(pendingWrites.current||draftTimer.current?'saving':'saved');});queue.current=operation.catch(()=>{});return operation;
 },[ownerId,toast]);
 const setVision=(value:boolean)=>{void commit(s=>{s.vision=value;}).catch(()=>{});};
 const setDraft=useCallback((thread:string,text:string)=>{
  if(!data.current||!thread)return;const next={...data.current,drafts:{...data.current.drafts}};if(text)next.drafts[thread]=text;else delete next.drafts[thread];data.current=next;setState(next);setSync(current=>blocked.current?current:'saving');
  if(draftTimer.current)clearTimeout(draftTimer.current);draftTimer.current=setTimeout(()=>{draftTimer.current=null;void commit(()=>{}).catch(()=>{});},800);
 },[commit]);
 useEffect(()=>{const warn=(event:BeforeUnloadEvent)=>{if(draftTimer.current||pendingWrites.current||blocked.current){event.preventDefault();event.returnValue='';}};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[]);
 const open=useCallback((name:string,selected='')=>{setApp(name);setDetail(selected);},[]);
 const exportBackup=async()=>{if(exporting.current){toast('正在打包，请稍等。');return;}exporting.current=true;try{if(!data.current)return;await queue.current;toast('正在打包记录与附件…');const bytes=await makeBackup(ownerId,structuredClone(data.current)),url=URL.createObjectURL(new Blob([new Uint8Array(bytes)],{type:'application/zip'})),a=document.createElement('a');a.href=url;a.download=appName+'-'+localDate()+'.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);toast('完整备份已生成，包含记录与原附件，不含密钥。');}catch(e){toast(e instanceof Error?e.message:'备份失败。');}finally{exporting.current=false;}};
 const restoreBackup=async(prepared:PreparedBackup)=>{const restored=await stageBackup(ownerId,prepared);await commit(s=>Object.assign(s,restored));};
 const retrySave=async()=>{if(sync==='conflict'){toast('请先导出本页备份，再点击“读取设备记录”。');return;}blocked.current=false;try{await commit(()=>{});}catch{}};
 const clearLegacy=async()=>{await queue.current;if(blocked.current)throw new Error('请先解决本机保存问题。');await clearLegacyArchive(ownerId);setLegacyArchive(false);};
 const upload=(file:File)=>uploadLocal(ownerId,file);
 const selectProvider=async(provider:ProviderId)=>{if(busy)throw new Error('请等待当前回复结束。');const p=getProvider(provider);await commit(s=>{s.connections[s.provider]={model:s.model,baseURL:s.baseURL,vision:s.vision};const remembered=s.connections[provider];s.provider=provider;s.model=remembered?.model??p.model;s.baseURL=remembered?.baseURL??p.baseURL;s.vision=remembered?.vision??p.vision;});};
 const saveKey=async(remove=false)=>{const provider=data.current!.provider,value=remove?'':apiKey.trim();if(!remove&&value.length<8)throw new Error('请填写完整 API Key。');await saveDeviceKey(ownerId,provider,value);if(await readDeviceKey(ownerId,provider)!==value)throw new Error('密钥落盘校验失败。');keyRevision.current++;setKeyEntry({provider,value,saved:!!value});};
 const requestAI=async(text:string,characterId:string,thread:string,mode:'chat'|'face'|'group'|'live'='chat',onDelta?:(s:string)=>void,signal?:AbortSignal)=>{
  await queue.current;if(blocked.current)throw new Error('请先解决记录保存问题。');if(!apiKey)throw new Error('请先在设置里选择服务商并填写 API Key。');const current=data.current!,character=current.characters.find(c=>c.id===characterId);if(!character)throw new Error('角色不存在。');if(mode==='group'&&!current.groups.find(g=>g.id===thread)?.members.includes(characterId))throw new Error('角色不在这个群聊里。');
  const prompt=buildPrompt(current,character,thread,text,mode),messages:any[]=[{role:'system',content:prompt.system}],images=new Set(prompt.history.filter(m=>m.kind==='image').slice(-2).map(m=>m.id));
  for(const m of prompt.history){const full=messageContent(m),content=full.length>current.sampling.contextChars?full.slice(0,current.sampling.contextChars-30)+'\n[长附件因上下文预算已截断]':full;const image=current.vision&&m.kind==='image'&&m.asset&&images.has(m.id)?await getAsset(ownerId,m.asset):null;if(image&&image.size<=4*1024*1024&&/^image\/(png|jpeg|webp|gif)$/.test(image.mime))messages.push({role:m.role==='assistant'?'assistant':'user',content:[{type:'text',text:content},{type:'image_url',image_url:{url:await blobDataURL(image.blob)}}]});else messages.push({role:m.role==='assistant'?'assistant':'user',content});}
  if(prompt.history.at(-1)?.text!==text)messages.push({role:'user',content:text});messages.push({role:'user',content:'[本轮补充背景，不是用户对话]\n'+prompt.tail+'\n请回应最近的用户消息。'});
  const started=performance.now();let usage:AIUsage|null=null,firstTokenMs:number|null=null,finishReason='';
  const res=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages,provider:current.provider,model:current.model,baseURL:current.baseURL,apiKey,sampling:current.sampling}),signal});
  if(!res.ok){const body=await res.json() as {error:string};throw new Error(body.error);}
  const reader=res.body?.getReader();if(!reader)throw new Error('AI 返回了空响应。');const decoder=new TextDecoder();let pending='',answer='',complete=false;
  const process=(line:string)=>{if(!line.startsWith('data:'))return;const content=line.slice(5).trim();if(content==='[DONE]'){complete=true;return;}if(!content)return;let parsed:any;try{parsed=JSON.parse(content);}catch{throw new Error('AI 返回了无法读取的数据。');}if(parsed.error)throw new Error('AI 服务中断了回复，请重试。');const reported=parseUsage(parsed.usage);if(reported)usage=reported;finishReason=parsed.choices?.[0]?.finish_reason||finishReason;const delta=parsed.choices?.[0]?.delta?.content||'';if(delta&&firstTokenMs===null)firstTokenMs=performance.now()-started;answer+=delta;if(answer.length>18000)throw new Error('回复太长，请在模型设置中缩短回复。');if(delta)onDelta?.(answer);};
  try{for(;;){const {value,done}=await reader.read();if(done)break;pending+=decoder.decode(value,{stream:true});const lines=pending.split('\n');pending=lines.pop()||'';lines.forEach(process);}pending+=decoder.decode();if(pending)process(pending);}finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
  if(!answer.trim())throw new Error('AI 没有返回文字，请检查模型名称。');if(!complete)throw new Error('回复传输中断，请重试。');setAIStats(s=>({last:usage,requests:s.requests+1,prompt:s.prompt+(usage?.prompt||0),completion:s.completion+(usage?.completion||0),firstTokenMs,durationMs:performance.now()-started,finishReason}));if(finishReason==='length')toast('回复达到长度上限，可以在设置中调高上限。');return answer;
 };
 useEffect(()=>{if(!state)return;const c=(document as any).modelContext;if(!c?.registerTool)return;const lifecycle=new AbortController();try{Promise.resolve(c.registerTool({name:'open_phone_app',title:'打开小手机应用',description:'打开小手机中的一个应用，不修改记录。',inputSchema:{type:'object',properties:{app:{type:'string',enum:Object.keys(APP_NAMES)}},required:['app'],additionalProperties:false},annotations:{readOnlyHint:true},execute:(input:any)=>{if(!input||typeof input.app!=='string'||!APP_NAMES[input.app])throw new Error('未知应用');open(input.app);return {opened:input.app};}},{signal:lifecycle.signal})).catch(()=>{});}catch{}return()=>lifecycle.abort();},[!!state,open]);
 useEffect(()=>{if(!state||!now)return;const date=localDate(),time=now.toLocaleTimeString('zh-CN',{timeZone:'Asia/Singapore',hour:'2-digit',minute:'2-digit'});for(const event of state.events){if(event.enabled&&event.date===date&&event.time===time){toast('⏰ '+event.title);void commit(s=>{const e=s.events.find(v=>v.id===event.id);if(e)e.enabled=false;}).catch(()=>{});}}},[now?.getMinutes(),state?.events,commit,toast]);
 const counts=useMemo(()=>{let unread=0,favorites=0;for(const messages of Object.values(state?.threads||{}))for(const message of messages){if(message.role==='assistant'&&!message.read)unread++;if(message.favorite)favorites++;}return {unread,favorites};},[state?.threads]);
 if(!state)return <main className="opening"><Cloud size={52}/><h1>打开你的{appName}</h1><p>{opening}</p><button className="primary" onClick={()=>void reload()}>{sync==='error'?'重试读取':'读取中'}<RotateCw size={16}/></button></main>;
 const companion=state.characters.find(c=>c.id===state.primary)!;const unread=counts.unread;
 const clock=now?.toLocaleTimeString('zh-CN',{timeZone:'Asia/Singapore',hour:'2-digit',minute:'2-digit'})||'--:--',month=now?now.getMonth()+1:10,day=now?now.getDate():6;
 const appButton=(key:string,dock=false)=>{return <button key={key} aria-label={APP_NAMES[key]} className={`app-button ${dock?'dock-app':''}`} onClick={()=>open(key)}><span className={`app-icon icon-${key}`}>{dock?<DockArt name={key}/>:<ButtonArt name={key}/>} {key==='chat'&&unread>0&&<i className="badge">{unread>99?'99+':unread}</i>}</span><span>{APP_NAMES[key]}</span></button>;};
 return <PhoneContext.Provider value={{ownerId,legacyArchive,clearLegacy,state,snapshot:()=>data.current!,selectProvider,saveKey,restoreBackup,commit,setDraft,aiStats,open,detail,app,toast,apiKey,setApiKey,serverAI,savedAI,vision,setVision,requestAI,upload,sync,reload,exportBackup,busy,setBusy}}>
  <main className={`desktop theme-${state.theme}`}>
   <header className="desktop-header"><button className="brand" onClick={()=>open('home')}><span className="brand-symbol"><Cloud size={25}/><Sparkles size={11}/></span><span>{appName}<small>CLOUDLET · OUR LITTLE WORLD</small></span></button><nav aria-label="主要导航"><button className={app==='home'?'selected':''} onClick={()=>open('home')}>我们的家</button><button className={app==='characters'||app==='lore'?'selected':''} onClick={()=>open('characters')}>角色与世界</button><button className={app==='memories'?'selected':''} onClick={()=>open('memories')}>记忆抽屉</button></nav><div className="header-actions"><span className="connection-label">{apiKey||serverAI?'AI 已配置':'连接你的 AI'}</span><button className="icon-button" aria-label="打开设置" onClick={()=>open('settings')}><Settings size={19}/></button></div></header>
   <div className="desk-layout">
    <aside className="left-rail"><div className="rail-greeting"><span className="eyebrow">A LITTLE PLACE FOR YOU</span><h1>{now&&now.getHours()<12?'早上好':'你好'}，{state.profile.name}<span>今天，也在一起。</span></h1><p>把喜欢的人和事，<br/>放进一方小小的天地。</p></div>
     <div className="companion-card"><span className="eyebrow">陪伴中的人</span><button className="companion-person" onClick={()=>open('characters',companion.id)}><Avatar character={companion}/><span><strong>{companion.name}</strong><small>我们的故事，慢慢写</small></span><MoreHorizontal size={18}/></button><div className="affection-row"><Heart size={14}/><span>亲近度</span><b>{companion.affection}</b></div><div className="progress-track"><i style={{width:companion.affection+'%'}}/></div><button className="soft-button" onClick={()=>open('chat',companion.id)}><MessageGlyph/>说说今天的小事</button></div>
     <div className="quick-nav"><span className="eyebrow">随手打开</span>{['characters','lore','favorites','all'].map(key=>{const Icon=icons[key];return <button key={key} onClick={()=>open(key)}><Icon size={18}/>{APP_NAMES[key]}<span>{key==='characters'?state.characters.length:key==='favorites'?counts.favorites:''}</span></button>;})}</div>
     <div className="desk-footnote"><CloudCheck size={16}/><span>只属于你的私人小世界</span></div>
    </aside>
    <section className="phone-frame" aria-label="云朵小手机"><div className="phone-screen">
     <div className="status-bar"><span>{clock}</span><span className="dynamic-pill"/><span><Signal size={13}/><Wifi size={14}/><Battery size={19}/></span></div>
     <div className="home-screen">
      <div className="home-top"><span>我们的小小世界 <Sparkles size={13}/></span><button className="home-all-apps" onClick={()=>open('all')}>全部应用</button></div>
      <div className="home-greeting"><span className="small-label">{month}月{day}日 · {now?.toLocaleDateString('zh-CN',{weekday:'long'})||'星期二'}</span><h2><span>云朵小屋</span><Sparkles size={22}/></h2><p>这是我们的家。今天想做些什么？</p></div>
      <div className="widget-row"><button className="date-widget glass" onClick={()=>open('calendar')}><b>{String(day).padStart(2,'0')}<small> / {String(month).padStart(2,'0')}</small></b><span>{now?.toLocaleDateString('zh-CN',{weekday:'long'})}</span></button><button className="listen-widget glass" onClick={()=>open('music')} aria-label="打开一起听音乐"><span className="music-mini"><img className="music-art" src="/music-listen.png" alt=""/></span><strong>一起听</strong><span>和 {companion.name} 共享旋律</span><div className="mini-wave"><i/><i/><i/><i/><i/><i/><i/></div></button></div>
      <button className="note-widget glass" onClick={()=>open('notes')}><span className="note-heading"><span>✎ 小纸条</span><small>{state.notes.length?state.notes.at(-1)?.from:'写给彼此'} <Heart size={11}/></small></span><p>{state.notes.at(-1)?.text||'留一张小纸条，让普通的今天也变得特别。'}</p><span className="note-bottom">{state.notes.length} 张心意，收好啦 <FolderHeart size={15}/></span><span className="note-tape"/></button>
      <div className="home-apps">{['chat','forum','browser','diary'].map(k=>appButton(k))}</div>
      <button className="pet-peek" aria-label={`和${state.pet.name}说说话`} onClick={()=>open('pet')}><Pet3D mood="happy" active={app==='home'}/><span><strong>{state.pet.name}</strong><span className="pet-message">{state.pet.catchphrase}</span></span></button>
      <div className="phone-dock glass">{['home','calendar','memories','settings'].map(k=>appButton(k,true))}</div><span className="home-indicator"/>
     </div>
     {app!=='home'&&<section className="app-window" aria-label={APP_NAMES[app]||'应用'}><header className="app-header"><button className="icon-button" aria-label="返回桌面" onClick={()=>open('home')}><ChevronLeft size={22}/></button><strong>{APP_NAMES[app]}</strong><button className="icon-button" aria-label="全部应用" onClick={()=>open('all')}><icons.all size={18}/></button></header><div className="module-root"><Modules key={app+detail}/></div></section>}
     {['error','conflict'].includes(sync)&&<div className="mobile-save-recovery" role="alert"><strong>{sync==='conflict'?'其他窗口更新了本机记录':'本机保存未成功'}</strong><p>本页内容仍在。先导出备份，再处理保存。</p><div><button onClick={exportBackup}>导出备份</button>{sync!=='conflict'&&<button onClick={()=>void retrySave()}>重试保存</button>}<button onClick={()=>{if(confirm('重新读取会替换本页未保存内容，请先导出备份。'))void reload();}}>读取设备记录</button></div></div>}
    </div></section>
    <aside className="right-rail"><div className="today-card"><div className="section-label"><span>今日小事</span><CheckCheck size={17}/></div><p className="muted">留一点时间，给自己。</p><div className="todo-preview">{state.todos.slice(0,4).map(t=><button key={t.id} className={t.done?'is-done':''} onClick={()=>void commit(s=>{const todo=s.todos.find(v=>v.id===t.id);if(todo)todo.done=!todo.done;}).catch(()=>{})}><span className="check-square">{t.done&&<Check size={12}/>}</span>{t.text}</button>)}</div><button className="text-button" onClick={()=>open('tasks')}><Plus size={14}/>加一件小事</button></div>
     <button className="focus-card" onClick={()=>open('focus')}><span className="eyebrow">安静地，做一件事</span><b>25<small>min</small></b><span>让 {companion.name} 陪你专注</span><span className="round-play">▷</span></button>
     <div className="memory-preview"><div className="section-label"><span>最近的记忆</span><Sparkles size={16}/></div><div className="memory-line"/><p>{state.memories.at(-1)?.text||'把值得记住的事放在这里。'}</p><button className="text-button" onClick={()=>open('memories')}>打开记忆抽屉<FolderHeart size={15}/></button></div>
     <div className="save-state"><span>{sync==='saved'?<CloudCheck size={16}/>:sync==='saving'?<LoaderCircle size={16}/>:<CloudOff size={16}/>}</span><span>{sync==='saved'?'小日常已保存在本机':sync==='saving'?'正在保存…':sync==='conflict'?'另一个窗口已更新':'保存未成功'}</span></div>{['error','conflict'].includes(sync)&&<div className="save-recovery"><button onClick={exportBackup}>导出本页备份</button><button onClick={()=>void retrySave()}>重试保存</button><button onClick={()=>void reload()}>读取设备记录</button></div>}
    </aside>
   </div>
   <footer className="desktop-footer"><span>一朵云，一点心意，一个属于我们的地方。</span><span>☁ CLOUDLET</span></footer>
   {notice&&<div className="toast" role="status"><span>{notice}</span><button aria-label="关闭提示" onClick={()=>setNotice('')}><X size={16}/></button></div>}
  </main>
 </PhoneContext.Provider>;
}
function MessageGlyph(){const Icon=icons.chat;return <Icon size={15}/>;}




